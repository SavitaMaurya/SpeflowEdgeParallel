﻿using System;
using TechTalk.SpecFlow;

namespace WebShopTestAutomation.StepDefinitions
{
    [Binding]
    public class SearchFeatureSteps
    {
        [Then(@"I died")]
        public void ThenIDied()
        {  
            ScenarioContext.Current.Pending();        }
    }
}
