﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebShopTestAutomation.PageObjects
{
    public class SearchResultsPage
    {
              
        private WebDriverWait wait;
        //private readonly Actions actions;
        //private IJavaScriptExecutor js;
        WebDriver driver;
        bool desktop = true;
        public SearchResultsPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));
        }

        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'house-card__body')]")]
        //protected IWebElement ResultHouse { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'search-results__item')][last()]//div[contains(@class, 'house-card__action')]/a[contains(@class, 'house-card__button')]")]
        //protected IList<IWebElement> ScrollDown { get; set; }

        public IWebElement SearchResultHouse()
        {
            IWebElement ResultHouse = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'house-card__body')]")));
            return ResultHouse;
        }
        public IWebElement AllHouseIDs()
        {
            IWebElement AllHouseIDs = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//script[contains(text(),'content_ids')][last()]")));
            return AllHouseIDs;
        }

        public int ResultHouseCount()
        {
            Console.WriteLine("SerachResultsPage ResultHouseCount Entry");
            driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

            int houseCount = 0;
            Thread.Sleep(3000);
            List<IWebElement> CheckHousesAvailable = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'search-results__no-results')]")).ToList();
            if(CheckHousesAvailable.Count > 0)
            {
                houseCount = 0;
                Assert.IsTrue(true);
            }
            else
            {
                IWebElement ResultHouseTitle = null;
                try
                {
                    ResultHouseTitle = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'search-results__title')]//span[contains(@class, 'search-results__count')]")));
                    houseCount = Convert.ToInt32(ResultHouseTitle.Text);
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Retrying and the excpeption occured: " + ex);
                    driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                    ResultHouseTitle = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'search-results__title')]//span[contains(@class, 'search-results__count')]")));
                    houseCount = Convert.ToInt32(ResultHouseTitle.Text);
                }
            
            }

            Console.WriteLine("SerachResultsPage ResultHouseCount : " + houseCount); 

            Console.WriteLine("SerachResultsPage ResultHouseCount Exit");
            return houseCount;
        }

        public List<IWebElement> AllHousesOnPage()
        {
            //IWebElement ScrollDown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//*[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__action')]")));
            //IList<IWebElement> lstScrollDown = driver.Current(out desktop).FindElements(By.XPath("//*[contains(@class, 'search-results__item')][last()]//div[contains(@class, 'house-card__action')]/a[contains(@class, 'house-card__button')]"));

            //IWebElement ScrollDown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__carousel-item')][not(@aria-hidden = 'true')]")));
            //List<IWebElement> lstScrollDown = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__carousel-item')][not(@aria-hidden = 'true')]")).ToList();

            IWebElement ScrollDown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'house-card')]//a[contains(@class, 'house-card__link')]")));
            List<IWebElement> lstScrollDown = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-card')]//a[contains(@class, 'house-card__link')]")).ToList();

            return lstScrollDown;
        }
        public List<IWebElement> GetFirstHousePropertyButton()
        {

            //List<IWebElement> firstHouse = driver.Current(out desktop).FindElements(By.XPath("//*[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__action')]/a[contains(@class, 'house-card__button')]")).ToList();
            List<IWebElement> firstHouse = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__carousel-item')][not(@aria-hidden = 'true')]")).ToList();

            return firstHouse;

        }
        public string GetRentalPrice()
        {
            
                //string houseRental = houselocation.FindElement(By.XPath("//div[contains(@class, 'house-card__price')]/span")).Text;
             List<IWebElement> lstRentalHouses = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-card__price')]/span")).ToList();
            IWebElement lastHouseRental = lstRentalHouses[lstRentalHouses.Count - 1];

            Console.WriteLine("Number of houses on SR when fetching price as a different loctor is used : " + lstRentalHouses.Count);

            string houseRental = lastHouseRental.Text;

            houseRental = Regex.Replace(houseRental, @"\s", "");
            Console.WriteLine("Price of last house on the current SR page : " + houseRental);

            return houseRental;

        }

        public List<int> PriceOfAllHousesOnPage()
        {
            List<int> LstHousePrice = new List<int>();
            try
            {
                Console.WriteLine("SearchResultspage.cs Method- PriceOfAllHousesOnPage Entry ");

                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'house-card__price')]/span/em/span")));
                List<IWebElement> lstRentalHouses = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-card__price')]/span/em/span")).ToList();
                int houseCount = 0;
                foreach (IWebElement housePrice in lstRentalHouses)
                {
                   string houseRental = housePrice.Text;
                                        
                    if (string.IsNullOrEmpty(houseRental))
                    {
                        Console.WriteLine("House price is empty, house number on page: " + houseCount);
                       ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].scrollIntoView();", housePrice);
                        Console.WriteLine("Scrolled to house successfully");

                        lstRentalHouses = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-card__price')]/span/em/span")).ToList();

                        houseRental = lstRentalHouses[houseCount].Text;
                        houseRental = houseRental.Replace(@"\s", string.Empty);
                        houseRental = houseRental.Replace(".", string.Empty);
                    }
                    else
                    {
                        
                        houseRental = houseRental.Replace(@"\s", string.Empty);
                        houseRental = houseRental.Replace(".", string.Empty);
                       
                    }

                    int homeRental = Convert.ToInt32(houseRental);

                    LstHousePrice.Add(homeRental);
                    houseCount++;

                    Console.WriteLine("SearchResultspage.cs Method- PriceOfAllHousesOnPage Exit ");
                }
            }
            catch (Exception ex)
            {

                throw ex;

            }
            return LstHousePrice;


        }

        public List<IWebElement> GetSearchResultHouses()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//div[contains(@class, 'search-results__items')]//div[@class ='house-card']")));
            List<IWebElement> SearchResultHouse = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'search-results__items')]//div[@class ='house-card']")).ToList();
            return SearchResultHouse;
        }

        public List<IWebElement> GetSearchFilterText()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form-field__tag')]")));
            List<IWebElement> SearchFilterText = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'search-form-field__tag')]")).ToList();
            return SearchFilterText;
        }
        public List<IWebElement> FavoriteIcon()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//i[contains(@class, 'favourite-box__icon')]")));
            List<IWebElement> lstHouses = driver.Current(out desktop).FindElements(By.XPath("//i[contains(@class, 'favourite-box__icon')]")).ToList();

            return lstHouses;
        }

        public IWebElement FavoriteLink(bool desktop)
        {
            IWebElement favoriteLink = null;

            if (desktop)
            {
                //favoriteLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__user-content-desktop')]//li[contains(@class, 'header-favorites-link')]"))); // for desktop
                favoriteLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[@class = 'site-header__user-content-desktop']//li[contains(@class, 'header-favorites-link')]"))); // for desktop

            }
            else
            {
                favoriteLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'header-favorites-link')]"))); // for mobile
            }
                return favoriteLink;

        }

        public IWebElement GetGuestPickerDropdown()
        {
            IWebElement GuestPicker = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form-field--guests')]//input[@type = 'button']")));
            return GuestPicker;
        }
        IList<IWebElement> lstGuestDropdwn = null;
        public IList<IWebElement> SelectFromGuestPickerDropdown()
        {
            IWebElement GuestPicker = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__incrementbutton')]/button")));
           //lstGuestDropdwn = webdriver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__numberinput')]/input"));
            lstGuestDropdwn = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__incrementbutton')]"));
            return lstGuestDropdwn;
        }
        public IWebElement GetChildrenIncrementButton()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(lstGuestDropdwn[1]));
            IWebElement ChildrenIncrementButton = lstGuestDropdwn[1];
            return ChildrenIncrementButton;
        }

        public IWebElement GetCloseGuestPicker()
        {
            IWebElement FacilitiesOption = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'guestpicker__close')]/button")));
            return FacilitiesOption;
        }
        IWebElement FacilitiesOption = null;
        public IWebElement GetFacilitiesOption()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button")));
            IList<IWebElement> lstSubFilters = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button"));
            FacilitiesOption = lstSubFilters[3];
            return FacilitiesOption;
        }

        public IWebElement GetUtilityFacility()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'filters__group')]//div[contains(@class, 'filters__group-item')]//input[@type ='checkbox']")));
            IList<IWebElement> lstFacility = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'filters__group')]//div[contains(@class, 'filters__group-item')]//input[@type ='checkbox']"));
            IWebElement UtilityFacility = lstFacility[3];
            return UtilityFacility;
        }
 
        public IWebElement GetPriceFilter()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button")));
            IList<IWebElement> lstPriceFilters = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button"));
            IWebElement PriceOption = lstPriceFilters[0];
            return PriceOption;
        }

        public IWebElement GetPriceSlider()
        {
            IWebElement PriceSlider = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-track')]")));
           
            return PriceSlider;
        }

        public IWebElement GetPriceSliderElement(bool low)
        {
            IWebElement PriceSliderElement = null;
            if (low)
            {
                 PriceSliderElement = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-handle-2')]")));
            }
            else
              {
                PriceSliderElement = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-handle-1')]")));
            }

                return PriceSliderElement;
        }

        public List<IWebElement> GetCloseFacilities()
        {
            List<IWebElement> CloseFacilities = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'filters__close-button')]")).ToList();
            return CloseFacilities;
        }
        public IWebElement GetCloseFilterCross()
        {
            IWebElement CloseFilterCross = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'filters__title')]")));
            return CloseFilterCross;
        }

        public IWebElement GetSortingFilter()
        {
            IWebElement SortingFilter = null;

            if(!desktop)
            {
                SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'filters__sort')]//div[contains(@class, 'Select-value')]")));
            }
            else
            {
                SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@class, 'Select-value')]")));
                //SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@class, 'search-results__value-container')]/input")));
            }
            return SortingFilter;
        }

        public IWebElement GetSelectedSortingFilter()
        {
            IWebElement SelectedSortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//span[contains(@class, 'Select-value-label')]")));
            return SelectedSortingFilter;
        }
        public void WaitTillSortingFilterOpen()
        {
          wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@role, 'combobox')][@aria-expanded='true']")));
            
        }

        public IWebElement GetDestinationFilter()
        {
            IWebElement DestinationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-name')]")));
            return DestinationFilter;
        }

        public IWebElement GetSelectedFilter()
        {
            IWebElement SelectedFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'selected-facets')]//div[contains(@class, 'selected-facets__facet')]")));
            return SelectedFilter;
        }
        public IWebElement RemoveSelectedFilter()
        {
            IWebElement SelectedFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'selected-facets')]//div[contains(@class, 'selected-facets__facet')]//span[contains(@class, 'selected-facets__remove')]")));
            return SelectedFilter;
        }

        public List<IWebElement> GetSEOContent()
        {
            List<IWebElement> SEOContent = null;

            if (desktop)
            { 
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'breadcrumb')]//span[contains(@class, 'breadcrumb__lead')]")));
            SEOContent = driver.Current(out desktop).FindElements(By.XPath("//section[contains(@class, 'breadcrumb')]//span[contains(@class, 'breadcrumb__lead')]")).ToList();
            }
            else
            {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'landingpage-destination__breadcrumbs')]")));
            SEOContent = driver.Current(out desktop).FindElements(By.XPath("//section[contains(@class, 'landingpage-destination__content')]//h1[contains(@class, 'landingpage__title')]")).ToList();
            }
            return SEOContent;

                     
        }
         public List<IWebElement> GetTagClouds()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'tag-cloud__group')]")));
            List<IWebElement> TagClouds = driver.Current(out desktop).FindElements(By.XPath("//section[contains(@class, 'tag-cloud__group')]//ul//li/a")).ToList();
            return TagClouds;
        }
        public IWebElement GetFilterIcon()
        {
            IWebElement FilterIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'searchapp__narrow-button--filter')]")));
            return FilterIcon;
        }
        public IWebElement GetMapIcon()
        {
            IWebElement MapIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'searchapp__narrow-button--map')]")));
            return MapIcon;
        }
        public IWebElement GetSearchAfterFilter()
        {
            IWebElement SearchAfterFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'searchapp__narrow-action--show-homes')]")));
            return SearchAfterFilter;
        }
         public List<IWebElement> GetHPLinkForHouse()
        {
            List<IWebElement> HPLinkForHouse = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-card')]/a[contains(@href, '/p/')]")).ToList();
            return HPLinkForHouse;
        }

        public IWebElement GetPopularDateMessage()
        {
            IWebElement PopularDateMessage = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__popular-date')]")));
            return PopularDateMessage;
        }
    }
}
