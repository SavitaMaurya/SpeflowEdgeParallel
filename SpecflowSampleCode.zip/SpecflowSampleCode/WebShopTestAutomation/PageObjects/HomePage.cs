﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class HomePage
    {

        private WebDriverWait wait;
   
        WebDriver driver;
        bool desktop = true;
        public HomePage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IList<IWebElement> GetCookieButton()
        {
            IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.XPath("//button[contains(@class, 'cookiebot-button-accept-all')]")); //chnages on 2nd Jan 2019, as new pages directly accesses give cookie warning
            //IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.XPath("//button[contains(@class, 'cc_btn_accept_all')]"));
            //IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.Id("CybotCookiebotDialogBodyButtonAccept"));
            return CookieButton;

        }
        public IWebElement GetBurgerMenu()
        {
            IWebElement BurgerMenu = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__user-content-mobile-burgermenu')]")));
            return BurgerMenu;

        }

        public IWebElement GetCloseMenu()
        {
            IWebElement CloseMenu = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__user-content-mobile-burgermenu-icon-on')]")));
            return CloseMenu;

        }


        public IWebElement GetLocationFilter()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form-field__input-inner-wrapper')]/input")));
            return LocationFilter;

        }

        public IWebElement GetLocationSelected()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-name')]")));
            return LocationFilter;

        }
        public IWebElement GetDesinationClose()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-close')]")));
            return LocationFilter;

        }
        public List<IWebElement> SelectLocationFromList()
        {

            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")));
            List<IWebElement> SelectLocation = driver.Current(out desktop).FindElements(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")).ToList(); 
            return SelectLocation;
        }

        public IList<IWebElement> SelectArrivalDate()
        {
            IWebElement ArrivalDate = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]")));

            IList<IWebElement> lstArrivalDate = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]"));

            return lstArrivalDate;
        }

        public IWebElement GetHomePageSearchButton()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'frontpage-search__search-button')]")));
            return SearchButton;
        }

        public IWebElement GetSearchButton()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'search-form__search-button')]")));
            return SearchButton;
        }
             
        public IWebElement GetThemePageLink()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//nav[contains(@class, 'site-header__nav')]//li[contains(@class, 'themepicker')]//a")));
            return SearchButton;
        }

        public IWebElement GetCalenderRightArrow()
        {
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DayPickerNavigation')]//button[contains(@class, 'DayPickerNavigation__next')]")));
            return ArrivalCalender;
        }

        public IWebElement NewRenterLink()
        {
            IWebElement NewRenterLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'houseownerpicker')]/a")));
            return NewRenterLink;
        }

        public IWebElement LogoOnHomePage()
        {
            IWebElement LogoLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__logo-graphics')]/a")));
            return LogoLink;
        }

        public IWebElement GetGuestLogin()
        {
            IWebElement GuestLogin = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'loginpicker')]/a")));
            return GuestLogin;
        }

        public List<IWebElement> GetMyProfile()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'loginpicker')]//div[contains(@class, 'site-header--dropdown-invoker')]")));
            List<IWebElement> MyProfile = driver.Current(out desktop).FindElements(By.XPath("//li[contains(@class, 'loginpicker')]//div[contains(@class, 'site-header--dropdown-invoker')]")).ToList();
            return MyProfile;
        }
        public IWebElement GetViewBookings()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")));
            List<IWebElement> ProfileOptions = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")).ToList();
            IWebElement ViewBookings = ProfileOptions[0];
            return ViewBookings;

        }
        public IWebElement GetDeactivateAccount()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")));
            List<IWebElement> ProfileOptions = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")).ToList();
            IWebElement DeactivateAccount = ProfileOptions[1];
            return DeactivateAccount;

        }
        public IWebElement GetLogoutButton()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")));
            List<IWebElement> ProfileOptions = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'loginpanel')]//div[contains(@class, 'header-dropdown__item')]/a")).ToList();
            IWebElement LogoutButton = ProfileOptions[2];
            return LogoutButton;

        }

        public IWebElement GetHomeOwnerLogin()
        {
            IWebElement GuestLogin = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'houseowner__link')]")));
            return GuestLogin;
        }

        public IWebElement GetNewsLetterSignUpLink()
        {
            IWebElement NewsLetterSignUpLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'newsletterpicker')]/a")));
            return NewsLetterSignUpLink;
        }

        public IWebElement GetCountryChangeLink()
        {
            IWebElement countryFlagLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'languagepicker')]/div[contains(@class, 'site-header__languageflag')]")));
            return countryFlagLink;
        }

        public IWebElement SelectNewCountryFlag(string appendingURL)
        {
            string newflagPath = "//div[contains(@class, 'languagepanel__item')]//a[contains(@href, 'novasol" + appendingURL + "')]";
            IWebElement NewCountryFlag = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(newflagPath)));
            return NewCountryFlag;
        }

    }
}
