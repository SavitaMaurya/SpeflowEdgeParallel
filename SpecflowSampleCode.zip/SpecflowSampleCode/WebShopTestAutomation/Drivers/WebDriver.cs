﻿using System;
using System.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Safari;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Edge;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Interfaces;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using System.Reflection;
using System.IO;

namespace WebShopTestAutomation.Drivers
{
    public class WebDriver
    {
        private IWebDriver _currentWebDriver;
        //private WebDriverWait _wait;
      
        public static bool isDesktop = true;
        public IWebDriver Current(out bool desktop)
        {
                desktop = true;
                if (_currentWebDriver == null)
                {
                   _currentWebDriver = GetWebDriver(out desktop);
                   isDesktop = desktop;
                }
                else
                {
                  desktop = isDesktop;
                }

                 return _currentWebDriver;
           
        }

        //public WebDriverWait Wait
        //{
        //    get
        //    {
        //        if (_wait == null)
        //        {
        //            this._wait = new WebDriverWait(Current, TimeSpan.FromSeconds(120));
        //        }
        //        return _wait;
        //    }
        //}

        private IWebDriver GetWebDriver(out bool desktop)
        {
            IWebDriver driver = null;
            desktop = true;
            try
            {
                AppiumOptions app_options = new AppiumOptions();
                ChromeOptions chrome_options = new ChromeOptions();
                SafariOptions safariOptions = new SafariOptions();
                string executingPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                Console.WriteLine("assemblyrunningPath : " + executingPath);

                //ChromeDriverService service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                ChromeDriverService service = null;
                switch (Environment.GetEnvironmentVariable("Test_Browser"))
                {
                    
                    case "Desktop_IE":

                        Console.WriteLine("In Desktop IE mode");

                        string ieDriverPath = @"\WebDriversSetup\IEDriver";
                        desktop = true;

                        ieDriverPath = Path.GetFullPath(Path.Combine(executingPath + ieDriverPath));

                        var options = new InternetExplorerOptions();
                        options.IgnoreZoomLevel = true;
                        //options.AcceptInsecureCertificates = true; //IE DOESN'T ALLOW
                        //options.EnableNativeEvents = false; //AUTO SUGGEST LOCATION STOPPED POPING
                        options.InitialBrowserUrl = "http://localhost";
                        options.UnhandledPromptBehavior = UnhandledPromptBehavior.Accept;
                        options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        options.EnablePersistentHover = true;
                        driver = new InternetExplorerDriver(ieDriverPath, options, TimeSpan.FromSeconds(180));

                        driver.Manage().Window.Maximize();
                        //the below works but hell slow
                        //InternetExplorerDriverService ieService = InternetExplorerDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        //driver = new InternetExplorerDriver(ieService, options, TimeSpan.FromSeconds(180));
                        break;
                    case "Desktop_Chrome":
                        Console.WriteLine("In Desktop Chrome mode");
                        desktop = true;
                        chrome_options.AddArgument("--disable-extensions");
                        chrome_options.AddArgument("--proxy-server='direct://'");
                        chrome_options.AddArgument("--proxy-bypass-list=*");
                        chrome_options.AddArgument("--no-sandbox");
                        service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new ChromeDriver(service, chrome_options, TimeSpan.FromSeconds(120));
                        driver.Manage().Window.Maximize();
                        break;
                    case "Headless_Chrome":

                        Console.WriteLine("In Headless Chrome mode");

                        desktop = true;

                        //works fine even with commented as New Chrome driver package is availble in bin folder that's run on Linux too (9 jan 2019)
                        //string driverPath = "/opt/selenium/";
                        //string driverExecutableFileName = "chromedriver";
                        //chrome_options.BinaryLocation = "/opt/google/chrome/chrome";
                        //ChromeDriverService service_headless = ChromeDriverService.CreateDefaultService(driverPath, driverExecutableFileName);

                        Console.WriteLine("Headless Chrome service created successfully");

                        chrome_options.AddArgument("--no-sandbox");
                        chrome_options.AddArgument("--headless");
                        chrome_options.AddArgument("--window-size=1420,1080");
                        chrome_options.AddArgument("--disable-extensions");
                        chrome_options.AddArgument("--proxy-server='direct://'");
                        chrome_options.AddArgument("--proxy-bypass-list=*");
                        chrome_options.AddArgument("--disable-gpu"); //even will come redundant in case of linux 
                        chrome_options.AddArgument("--disable-dev-shm-usage"); // to fix -  error: unknown error: session deleted because of page crash
                        chrome_options.AddArgument("--remote-debugging-port=9222");
                        chrome_options.AddArgument("--remote-debugging-address=0.0.0.0");
                        chrome_options.AddArgument("--disable-infobars");
                        chrome_options.AddArgument("--user-data-dir=/data");
                        chrome_options.AddArgument("--ignore-certificate-errors");
                        chrome_options.AddArgument("--disable-features=VizDisplayCompositor"); //to save from zombie chrome process running
                        //chrome_options.AddArgument("--disable-setuid-sandbox");
                        //chrome_options.AddArgument("--privileged"); // can be a security risk
                        //chrome_options.AddArgument("--lang=en_US");
                        //chrome_options.AddArgument("--start-maximized");
                        //chrome_options.AddAdditionalCapability("useAutomationExtension", false);

                        //driver = new ChromeDriver(service_headless, chrome_options, TimeSpan.FromSeconds(120));

                        //To run headless chrome on Windows
                        service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new ChromeDriver(service, chrome_options, TimeSpan.FromSeconds(180));
                        driver.Manage().Window.Maximize();
                        break;


                    case "Desktop_Firefox":
                        Console.WriteLine("In Desktop Firefox mode");
                        //ProfilesIni prof = new ProfilesIni();
                        //FirefoxProfile ffProfile = prof.getProfile("myProfile");

                        //string ffDriverPath = @"..\WebDriversSetup\FirefoxDriver";

                        string ffDriverPath = @"\WebDriversSetup\FirefoxDriver";
                        ffDriverPath = Path.GetFullPath(Path.Combine(executingPath + ffDriverPath));
                        desktop = true;
                        var ffOption = new FirefoxOptions
                        {
                            AcceptInsecureCertificates = true,
                            
                        };
                        //op.AddArguments("-headless");

                        //it works fine but becomes slow like IE so commenting
                        //FirefoxDriverService ffService = FirefoxDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        //driver = new FirefoxDriver(ffService, op, TimeSpan.FromSeconds(120));


                        driver = new FirefoxDriver(ffDriverPath, ffOption, TimeSpan.FromSeconds(120));
                        driver.Manage().Window.Maximize();
                        break;

                    case "Desktop_Edge":

                        Console.WriteLine("In Desktop Edge mode");
                        desktop = true;

                        EdgeOptions eOptions = new EdgeOptions();
                        eOptions.AcceptInsecureCertificates = true;

                        //EdgeDriverService edgeService = EdgeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        //driver = new EdgeDriver(edgeService, eOptions, TimeSpan.FromSeconds(120));

                        string edgeDriverPath = @"\WebDriversSetup\EdgeDriver";
                        
                        edgeDriverPath = Path.GetFullPath(Path.Combine(executingPath + edgeDriverPath));
                        driver = new EdgeDriver(edgeDriverPath);
                        //driver = new EdgeDriver(edgeDriverPath, eOptions, TimeSpan.FromSeconds(120)); // doesn't work this way

                        driver.Manage().Window.Maximize();
                        break;
                    case "Mobile_Chrome":
                        Console.WriteLine("In Mobile Chrome mode");
                        app_options.AddAdditionalCapability("platformName", "Android");

                        desktop = false;
                        //driver = new AndroidDriver<AppiumWebElement>(new Uri("http://127.0.0.1:4723/wd/hub"), chrome_options, TimeSpan.FromSeconds(60));
                        //driver = new RemoteWebDriver(new Uri("http://127.0.0.1:4723/wd/hub"), app_options.ToCapabilities()); //works with appium

                        chrome_options.AddArgument("--disable-extensions");
                        chrome_options.AddArgument("--proxy-server='direct://'");
                        chrome_options.AddArgument("--proxy-bypass-list=*");
                        chrome_options.AddArgument("--no-sandbox");
                        chrome_options.AddArgument("--window-size=640,700"); //phone portrait(x,y)
                        //chrome_options.AddArgument("--window-size=1080,640"); //tablet portrait(x,y)
                        //chrome_options.AddArgument("--window-size=360,640"); //landscape
                        service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new ChromeDriver(service, chrome_options, TimeSpan.FromSeconds(120));

                        break;

                    case "Tablet_Chrome":
                        Console.WriteLine("In Tablet Chrome mode");
                        desktop = true;

                        chrome_options.AddArgument("--disable-extensions");
                        chrome_options.AddArgument("--proxy-server='direct://'");
                        chrome_options.AddArgument("--proxy-bypass-list=*");
                        chrome_options.AddArgument("--no-sandbox");
                        chrome_options.AddArgument("--window-size=1080,700"); //tablet portrait(x,y)
                        //chrome_options.AddArgument("--window-size=360,640"); //landscape
                        service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new ChromeDriver(service, chrome_options, TimeSpan.FromSeconds(120));

                        break;
                     
                        case "Tablet_Firefox":

                        desktop = true;

                        var ffOptions = new FirefoxOptions();
                        ffOptions.AcceptInsecureCertificates = true;
                        ffOptions.AddArgument("--width=1080");
                        ffOptions.AddArgument("--height=700");

                        FirefoxDriverService ffService1 = FirefoxDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new FirefoxDriver(ffService1, ffOptions, TimeSpan.FromSeconds(120));
                        //driver = new FirefoxDriver(ffOptions);
                      
                        break;


                    default:
                        Console.WriteLine("In default : Test-Browser is - " + Environment.GetEnvironmentVariable("Test_Browser"));
                        desktop = true;
                        chrome_options.AddArgument("--start-maximized");
                        driver.Manage().Window.Maximize();
                        
                        driver = new ChromeDriver(chrome_options);
                        break;
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return driver;
        }

        public void Quit()
        {
            _currentWebDriver?.Quit();
        }

        public void Dispose()
        {
            _currentWebDriver?.Dispose();
        }
    }
}
