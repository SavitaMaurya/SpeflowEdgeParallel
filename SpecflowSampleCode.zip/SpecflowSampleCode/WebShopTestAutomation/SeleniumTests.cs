﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using System.Configuration;
using WebShopTestAutomation.Drivers;
using System.Threading;
using WebShopTestAutomation.PageObjects;
using System.Text.RegularExpressions;
using OpenQA.Selenium.Interactions;
using WebShopTestAutomation;
using NUnit.Framework;
using Microsoft.Extensions.Configuration;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Collections.ObjectModel;

namespace WebShopTestAutomation
{
    [TestFixture]
    public class SeleniumTests
    {
        bool desktop = true;

        public bool IsDialogPresent(WebDriver driver)
        {
            IAlert alert = SeleniumExtras.WaitHelpers.ExpectedConditions.AlertIsPresent().Invoke(driver.Current(out desktop));
            return (alert != null);
        }
        public void ClickOnCookiesButton(WebDriver driver)
        {

            try
            {
                HomePage objHomePage = new HomePage(driver);

                List<IWebElement> lstcookiesButton = objHomePage.GetCookieButton().ToList();

                if (lstcookiesButton.Count > 0)
                {
                    Console.WriteLine("Cookies pop up occurred");
                    IWebElement cookiesButton = lstcookiesButton[0];

                    if (cookiesButton.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", cookiesButton);

                    }

                    driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                    //take snapshot
                    ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("AfterClickOnCookieAccept_1.png", ScreenshotImageFormat.Png);

                    lstcookiesButton = null;
                    lstcookiesButton = objHomePage.GetCookieButton().ToList();

                    if (lstcookiesButton.Count > 0)
                    {
                        Console.WriteLine("Cookies pop up still exist");
                        if (cookiesButton.Enabled)
                        {
                            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", cookiesButton);

                        }

                    //take snapshot
                    ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("AfterClickOnCookieAccept_2.png", ScreenshotImageFormat.Png);
                    }

                }
                else
                {
                    Console.WriteLine("No - Cookies pop up occurred");
                }

            }

            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }

        }

        public void ClickAndWriteOnAnywhereInWorldOption(WebDriver driver, string location)
        {
            try
            {


                HomePage objHomePage = new HomePage(driver);
                IWebElement locationElement = objHomePage.GetLocationFilter();

                if (locationElement.Enabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", locationElement);

                }
                location = Regex.Replace(location, @"\s", "");
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

                locationElement = objHomePage.GetLocationFilter();

                int charCount = 0;
                foreach (char c in location)
                {
                    charCount++;
                    locationElement.SendKeys(c.ToString());

                    if (charCount == 3)
                    {
                        Thread.Sleep(3000);
                    }
                }

                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                Console.WriteLine("Location entered in destination search: " + location);

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }

        }



        public void SelectlocationfromDropdown(WebDriver driver)
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);

                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

                List<IWebElement> selectedLocation = objHomePage.SelectLocationFromList();

                if (selectedLocation.Count == 0)
                {
                    Console.WriteLine("Location dropdown not populated initially");
                    IWebElement locationElement = objHomePage.GetLocationFilter();

                    if (locationElement.Enabled)
                    {
                        Console.WriteLine("Location textbox is enabled");
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", locationElement);
                    }
                    locationElement = objHomePage.GetLocationFilter();
                    locationElement.SendKeys(Keys.Backspace);
                    driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                }

                selectedLocation = objHomePage.SelectLocationFromList();
                if (selectedLocation.Count > 0)
                {
                    Console.WriteLine("Location dropdown populated successfully, count : " + selectedLocation.Count);

                    if (selectedLocation[0].Enabled)
                    {
                        Console.WriteLine("Location textbox is enabled after retrying to get the location");
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", selectedLocation[0]);
                    }

                    string destinationFilterText = objHomePage.GetLocationSelected().Text;

                    Console.WriteLine("Selected Location : " + destinationFilterText);
                }
                else
                {
                    Assert.Fail("Location dropdown not populated");
                }
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
            }

            catch (Exception ex)
            {
                ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("LocationHomePage.png", ScreenshotImageFormat.Png);
                driver.Quit();
                throw ex;
            }

        }


        public void ChooseDateFiltersForArrivalAndDeparture(WebDriver driver)
        {
            try
            {
                DateTime cdate = new DateTime();
                cdate = DateTime.Today.Date;


                string assemblyrunningPath = new FileInfo(Assembly.GetExecutingAssembly().Location).ToString();

                string configPath = Path.GetFullPath(Path.Combine(assemblyrunningPath, @".."));
                var config = new ConfigurationBuilder().SetBasePath(configPath).AddJsonFile("specflow.json").Build();

                DateTime arrivalDate = new DateTime();

                arrivalDate = cdate.AddDays(Convert.ToInt32(config["ArrivalInDays"]));

                Console.WriteLine("Arrival Date: " + arrivalDate.ToString());

                DateTime deptDate = new DateTime();


                deptDate = arrivalDate.AddDays(Convert.ToInt32(config["DepartureInDays"]));

                Console.WriteLine("Departure Date: " + deptDate.ToString());

                HomePage objHomePage = new HomePage(driver);

                int Count = 0;

                List<IWebElement> lstArrivalDate = objHomePage.SelectArrivalDate().ToList();


                bool arrivalDateSelected = false;

                foreach (IWebElement element in lstArrivalDate.ToList())
                {
                    Count = 1;
                    if (arrivalDate.Day.ToString() == element.Text)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                        arrivalDateSelected = true;
                        break;

                    }
                    lstArrivalDate.Remove(element);

                    Count++;
                }


                if (!arrivalDateSelected)
                {

                    IWebElement calenderArrow = objHomePage.GetCalenderRightArrow();

                    if (calenderArrow.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                    }

                    lstArrivalDate = objHomePage.SelectArrivalDate().ToList();

                    foreach (IWebElement element in lstArrivalDate.ToList())
                    {
                        Count = 1;
                        if (arrivalDate.Day.ToString() == element.Text)
                        {
                            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                            arrivalDateSelected = true;
                            break;

                        }
                        lstArrivalDate.Remove(element);

                        Count++;
                    }

                }
                //Check departure calender is open or not

                bool departureDateSelected = false;

                List<IWebElement> lstDepartureDate = lstArrivalDate; //Remaining dates in calender

                foreach (IWebElement element in lstDepartureDate)
                {
                    if (deptDate.Day.ToString() == element.Text)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                        departureDateSelected = true;
                        break;
                    }
                }

                if (!departureDateSelected)
                {

                    IWebElement calenderArrow = objHomePage.GetCalenderRightArrow();

                    if (calenderArrow.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                    }

                    lstDepartureDate = objHomePage.SelectArrivalDate().ToList();

                    foreach (IWebElement element in lstDepartureDate.ToList())
                    {
                        Count = 1;
                        if (deptDate.Day.ToString() == element.Text)
                        {
                            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                            departureDateSelected = true;
                            break;

                        }
                        lstDepartureDate.Remove(element);

                        Count++;
                    }

                }

            }

            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }


        }

        public void ClickOnHomePageSearchButton(WebDriver driver)
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);
                // IWebElement searchElement = driver.FindElement(By.TagName("button")).FindElement(By.ClassName("frontpage-search__search-button"));
                IWebElement searchElement = null;
                try
                {
                    searchElement = objHomePage.GetHomePageSearchButton();

                    if (searchElement.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", searchElement);

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    searchElement = objHomePage.GetHomePageSearchButton();

                    if (searchElement.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", searchElement);

                    }
                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }

        }
        public void SelectHousefromtheListofHouses(WebDriver driver, IWebElement houseLocation)
        {
            try
            {
                Console.WriteLine("SelectHousefromtheListofHouses method entered");
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);

                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

                List<IWebElement> lsthouselocations = objSearchResults.AllHousesOnPage();

                houseLocation = lsthouselocations[lsthouselocations.Count - 1];
                Console.WriteLine("SelectHousefromtheListofHouses House Count just before selecting  : " + lsthouselocations.Count);

                Console.WriteLine("Current page title : " + driver.Current(out desktop).Title);

                if (lsthouselocations.Count > 24)
                {
                    Console.WriteLine("House count greater than 24");
                    for (int i = 0; i < lsthouselocations.Count; i++)
                    {
                        Console.WriteLine(lsthouselocations[i].GetAttribute("href"));
                    }
                }

                if (houseLocation.Enabled)
                {
                    Console.WriteLine("house is enabled to be clicked");

                    try
                    {
                        string houseURL = houseLocation.GetAttribute("href");
                        Console.WriteLine("House URL on SR page : " + houseURL + "Snapshot just before click a house : ");
                        //take screenshot
                        ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("BeforeClickonHouse.png", ScreenshotImageFormat.Png);

                        ClickOnCookiesButton(driver);

                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", houseLocation);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);

                    }

                }
                Console.WriteLine("House selected successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                driver.Quit();
                throw ex;

            }
        }

        int HouseCount = 0;
        public int CheckContentOnSearchFilterResultPage(WebDriver driver, string location)
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);

                string houselocation = objSearchResults.SearchResultHouse().Text;
                bool isLocationCorrect = houselocation.Contains(location);

                if (!isLocationCorrect)
                {
                    //test case fail

                    Assert.AreNotSame(1, 1);
                }

                HouseCount = objSearchResults.ResultHouseCount();

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }

            return HouseCount;
        }

        public bool CheckForDuplicateHouseOnResultPage(WebDriver driver)
        {
            bool isDuplicate = false;
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);

                List<string> lstHouseIds = new List<string>();

                List<IWebElement> lstHouses = objSearchResults.GetSearchResultHouses();

                int houseCount = lstHouses.Count();

                Console.WriteLine("House Count on SR: " + houseCount);

                if (houseCount > 0)
                {
                    for (int i = 0; i < houseCount; i++)
                    {
                        lstHouseIds.Add(lstHouses[i].GetAttribute("id").ToString());
                    }

                }

                //    IWebElement allHouseIDs = objSearchResults.AllHouseIDs();

                //string houseIDs = allHouseIDs.GetAttribute("innerHTML");
                //int startindex = houseIDs.IndexOf("[");
                //int endindex = houseIDs.IndexOf("]");


                //int length = (endindex - 2) - (startindex + 1);
                //houseIDs = houseIDs.Substring(startindex + 1, length);
                //houseIDs = houseIDs.Replace(@"\\", "");

                //List<string> lstHouses = new List<string>();

                //lstHouses = houseIDs.Split(',').ToList();
                lstHouseIds = lstHouseIds.OrderBy(q => q).ToList();

                if (lstHouseIds.Count() != lstHouseIds.Distinct().Count())
                {
                    isDuplicate = true;
                }

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
            return isDuplicate;
        }


        public List<string> GetListOfHousesOnSerachResultsPage(WebDriver driver)
        {
            List<string> lstHouses = null;
            try
            {
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement allHouseIDs = objSearchResults.AllHouseIDs();

                string houseIDs = allHouseIDs.GetAttribute("innerHTML");
                int startindex = houseIDs.IndexOf("[");
                int endindex = houseIDs.IndexOf("]");


                int length = (endindex - 2) - (startindex + 1);
                houseIDs = houseIDs.Substring(startindex + 2, length);
                houseIDs = houseIDs.Replace(@"\\", "");
                houseIDs = houseIDs.Replace(@"\", "");
                lstHouses = new List<string>();
                if (houseIDs.Contains(","))
                {
                    lstHouses = houseIDs.Split(',').ToList();
                }
                else
                {
                    lstHouses.Add(houseIDs);
                }
                lstHouses = lstHouses.OrderBy(q => q).ToList();

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
            return lstHouses;
        }

        public IWebElement ScrollDownToBottomOfSearchResultsPage(WebDriver driver)
        {
            SearchResultsPage objSearchResults = new SearchResultsPage(driver);
            IWebElement houselocation = null;
            try
            {
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                List<IWebElement> lsthouselocations = objSearchResults.AllHousesOnPage();
                Console.WriteLine("Scroll to element found successfully, house count : " + lsthouselocations.Count);
                houselocation = lsthouselocations[lsthouselocations.Count - 1];
                ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].scrollIntoView(true);", houselocation);
                Console.WriteLine("Scrolled successfully");
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                lsthouselocations = objSearchResults.AllHousesOnPage();
                houselocation = lsthouselocations[lsthouselocations.Count - 1];
                Console.WriteLine("House count after scrolling as again fetching: " + lsthouselocations.Count);

                if (lsthouselocations.Count > 24)
                {
                    //take screenshot
                    ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("SRHouseCountError.png", ScreenshotImageFormat.Png);
                }

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
            return houselocation;
        }

               
      

    }
}